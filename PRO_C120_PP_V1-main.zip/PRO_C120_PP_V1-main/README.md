# PRO_C120_PP_V1
PROBANDO EL CHATBOT  
Python. NLTK.  
  
Bot de atención al cliente.  
  
### Texto en inglés: PRO-C120-Project-Boilerplate
